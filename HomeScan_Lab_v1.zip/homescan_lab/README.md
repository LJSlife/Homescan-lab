# HomeScan Lab — zero-cost iPhone browser prototype

## What it does
- Opens the rear iPhone camera in Safari.
- Runs a free in-browser COCO-SSD object detector.
- Records useful household object classes such as fridge, oven, microwave, TV, laptop, sink, furniture, bed and toilet.
- Lets you correct quantities, rename items, add missed items and delete false detections.
- Saves room inventories only in the browser's local storage.
- Exports all saved room data as JSON.

## Important limits of this first test
- It identifies broad classes, not exact brands/models/serial numbers.
- It will miss objects outside the COCO model's training categories (for example, dishwasher and boiler are not standard COCO classes).
- It may misidentify objects; that is part of what this prototype is intended to measure.
- iPhone camera access requires the site to be served over HTTPS.
- The TensorFlow.js and COCO-SSD libraries are loaded from jsDelivr. The service worker may cache them after first use, but internet access is expected for first load.

## Free deployment option: GitHub Pages
1. Create a free GitHub account if you do not already have one.
2. Create a new PUBLIC repository, e.g. `homescan-lab`.
3. Upload all five files in this folder to the repository root.
4. In the repository, open **Settings → Pages**.
5. Under **Build and deployment**, choose **Deploy from a branch**.
6. Choose the `main` branch and `/ (root)` folder, then Save.
7. GitHub will give you an HTTPS website address.
8. Open that address in Safari on your iPhone.
9. Tap **Start camera** and allow camera access.
10. Optional: Safari Share button → **Add to Home Screen**.

## First test protocol
Use only one room first — ideally the kitchen.

1. Enter `Kitchen` as the room name.
2. Start the camera.
3. Start Scan.
4. Walk slowly around the room for 30–60 seconds.
5. Stop Scan.
6. Compare the detected list with the major useful items actually in the room.
7. Correct quantities, delete false positives, and manually add missed useful items.
8. Save the room.

Record four numbers separately:
- Useful item types actually present.
- Useful item types automatically detected correctly.
- False detections.
- Useful items missed.

Those four numbers tell us whether the walkthrough idea is worth pushing further.

## Privacy
This build has no custom backend and does not upload the room inventory to a server. The app code itself and third-party JS libraries are downloaded over the internet from the hosting/CDN services. Treat this as an experimental build, not a finished privacy/security product.
